# PayLite — Wise-style Android prototype

Kotlin + Jetpack Compose (Material 3). Demo data only, no real money moves.

## Run
1. Install Android Studio (Ladybug or newer).
2. File → Open → select this `PayLite` folder. Let Gradle sync (it downloads the SDK/deps).
3. Press ▶ Run on an emulator or a USB-connected phone (Developer options → USB debugging).
   APK: Build → Build App Bundle(s)/APK(s) → Build APK(s).

## Features
- Home: total balance, multi-currency balance cards, quick actions, recent activity
- Send: amount + currency, transparent fee breakdown, live rate, recipient pick/add, review, success
- Convert between own balances, Add money, Activity list, Account page

## Code map
- `WalletViewModel.kt` – currencies, demo FX rates, fee formula, balances, transactions
- `ui/Screens.kt` – all screens · `ui/Components.kt` – shared widgets · `ui/Theme.kt` – colors
- `MainActivity.kt` – navigation + bottom bar

## Next steps toward a real product
- Live FX rates API, backend (auth, ledger, KYC), Room/DataStore persistence
- Payments need a licensed partner (e.g. EMI license or Banking-as-a-Service provider)
