# PayLite Android (WebView)
Opens https://hazalerenn33-hash.github.io/PayLite/ as a native Android app.
Update the website (index.html) and the app shows the new version automatically — no new APK needed.
Built by .github/workflows/build.yml in the repo (unzips PayLite.zip and runs ./gradlew assembleDebug).
