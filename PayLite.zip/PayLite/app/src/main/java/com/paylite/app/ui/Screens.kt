package com.paylite.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paylite.app.Currencies
import com.paylite.app.Quote
import com.paylite.app.Recipient
import com.paylite.app.WalletViewModel
import com.paylite.app.money
import java.util.Locale

// ---------------------------------------------------------------- Home

@Composable
fun HomeScreen(
    vm: WalletViewModel,
    onSend: () -> Unit,
    onConvert: () -> Unit,
    onAdd: () -> Unit,
    onSeeAll: () -> Unit,
) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        item {
            Spacer(Modifier.height(20.dp))
            Text("Total balance", color = Color.Gray)
            Text(
                vm.totalInEur().money("EUR"),
                fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Forest,
            )
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickAction("Send", Icons.AutoMirrored.Filled.Send, onSend)
                QuickAction("Add", Icons.Filled.Add, onAdd)
                QuickAction("Convert", Icons.Filled.SwapHoriz, onConvert)
            }
            Spacer(Modifier.height(24.dp))
            Text("Balances", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(vm.balances.keys.sorted()) { code ->
                    BalanceCard(code, vm.balances[code] ?: 0.0)
                }
            }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Recent activity", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                )
                TextButton(onClick = onSeeAll) { Text("See all") }
            }
        }
        items(vm.transactions.take(5), key = { it.id }) { TxRow(it) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun QuickAction(label: String, icon: ImageVector, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(56.dp).clip(CircleShape).background(Lime).clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, contentDescription = label, tint = Forest) }
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun BalanceCard(code: String, amount: Double) {
    val c = Currencies.get(code)
    Column(
        Modifier
            .width(150.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(16.dp)
    ) {
        Text(c.flag, fontSize = 26.sp)
        Spacer(Modifier.height(18.dp))
        Text(String.format(Locale.US, "%,.2f", amount), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(c.code, color = Color.Gray)
    }
}

// ---------------------------------------------------------------- Send flow

@Composable
fun SendScreen(vm: WalletViewModel, onDone: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    var amountText by remember { mutableStateOf("100") }
    var from by remember { mutableStateOf("EUR") }
    var to by remember { mutableStateOf("PLN") }
    var recipient by remember { mutableStateOf<Recipient?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<Quote?>(null) }

    val amount = parseAmount(amountText)
    val q = vm.quote(amount, from, to)
    val balance = vm.balances[from] ?: 0.0

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        when (step) {
            0 -> {
                Text("Send money", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                AmountRow("You send", amountText, { amountText = it }, from, { from = it },
                    codes = vm.balances.keys.sorted())
                Text(
                    "Balance: ${balance.money(from)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (amount > balance) MaterialTheme.colorScheme.error else Color.Gray,
                    modifier = Modifier.padding(6.dp),
                )
                FeeBreakdown(q, from, to)
                AmountRow("Recipient gets", String.format(Locale.US, "%,.2f", q.receiveAmount), null, to, { to = it })
                Spacer(Modifier.height(16.dp))
                PrimaryButton("Continue", enabled = amount > 0 && amount <= balance) { step = 1 }
            }

            1 -> {
                BackHeader("Who are you sending to?") { step = 0 }
                val list = vm.recipients.filter { it.currency == to }
                if (list.isEmpty()) {
                    Text("No saved $to recipients yet.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                }
                list.forEach { r ->
                    RecipientRow(r) { recipient = r; step = 2 }
                }
                Spacer(Modifier.height(16.dp))
                NewRecipientForm(to) { name, acc ->
                    vm.addRecipient(name, to, acc)
                    recipient = vm.recipients.last()
                    step = 2
                }
            }

            2 -> recipient?.let { r ->
                BackHeader("Review transfer") { step = 1 }
                Spacer(Modifier.height(8.dp))
                KeyValue("You send", amount.money(from), bold = true)
                KeyValue("Fee", q.fee.money(from))
                KeyValue("We convert", q.amountConverted.money(from))
                KeyValue("Rate", String.format(Locale.US, "1 %s = %.4f %s", from, q.rate, to))
                KeyValue("${r.name} gets", q.receiveAmount.money(to), bold = true)
                KeyValue("Account", r.account)
                KeyValue("Arrives", "In seconds (demo)")
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Spacer(Modifier.height(16.dp))
                PrimaryButton("Confirm and send") {
                    vm.send(amount, from, r)
                        .onSuccess { result = it; error = null; step = 3 }
                        .onFailure { error = it.message }
                }
            }

            else -> {
                Spacer(Modifier.height(60.dp))
                Icon(
                    Icons.Filled.CheckCircle, contentDescription = null, tint = Forest,
                    modifier = Modifier.size(96.dp).align(Alignment.CenterHorizontally),
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    "Money sent!", style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally),
                )
                Text(
                    "${recipient?.name} receives ${result?.receiveAmount?.money(to)}",
                    color = Color.Gray, modifier = Modifier.align(Alignment.CenterHorizontally),
                )
                Spacer(Modifier.height(32.dp))
                PrimaryButton("Done") {
                    step = 0; amountText = "100"; recipient = null; onDone()
                }
            }
        }
    }
}

@Composable
private fun FeeBreakdown(q: Quote, from: String, to: String) {
    Column(Modifier.padding(start = 16.dp, top = 4.dp, bottom = 8.dp, end = 8.dp)) {
        KeyValue("−  Fee (0.45% + fixed)", q.fee.money(from))
        KeyValue("=  Amount we'll convert", q.amountConverted.money(from))
        KeyValue("×  Exchange rate", String.format(Locale.US, "%.4f", q.rate))
        if (from != to) Text("No hidden markup — mid-market rate (demo)", color = Forest,
            style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun RecipientRow(r: Recipient, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp),
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Lime),
            contentAlignment = Alignment.Center,
        ) { Text(r.name.take(1), fontWeight = FontWeight.Bold, color = Forest) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(r.name, fontWeight = FontWeight.SemiBold)
            Text("${Currencies.get(r.currency).flag} ${r.account}", color = Color.Gray,
                style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun NewRecipientForm(currency: String, onAdd: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var acc by remember { mutableStateOf("") }
    Text("Add a new $currency recipient", fontWeight = FontWeight.Bold)
    OutlinedTextField(name, { name = it }, label = { Text("Full name") },
        singleLine = true, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(acc, { acc = it }, label = { Text("IBAN / account number") },
        singleLine = true, modifier = Modifier.fillMaxWidth())
    PrimaryButton("Add and continue", enabled = name.isNotBlank() && acc.length >= 6) {
        onAdd(name.trim(), acc.trim())
    }
}

// ---------------------------------------------------------------- Convert

@Composable
fun ConvertScreen(vm: WalletViewModel, onBack: () -> Unit) {
    var amountText by remember { mutableStateOf("") }
    var from by remember { mutableStateOf("EUR") }
    var to by remember { mutableStateOf("PLN") }
    var msg by remember { mutableStateOf<String?>(null) }
    val amount = parseAmount(amountText)
    val q = vm.quote(amount, from, to)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        BackHeader("Convert balances", onBack)
        AmountRow("From", amountText, { amountText = it; msg = null }, from, { from = it },
            codes = vm.balances.keys.sorted())
        Text("Balance: ${(vm.balances[from] ?: 0.0).money(from)}", color = Color.Gray,
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(6.dp))
        FeeBreakdown(q, from, to)
        AmountRow("To", String.format(Locale.US, "%,.2f", q.receiveAmount), null, to, { to = it })
        msg?.let { Text(it, modifier = Modifier.padding(8.dp)) }
        PrimaryButton("Convert", enabled = amount > 0) {
            vm.convert(amount, from, to)
                .onSuccess { msg = "✅ Converted. New $to balance: ${(vm.balances[to] ?: 0.0).money(to)}"; amountText = "" }
                .onFailure { msg = "⚠️ ${it.message}" }
        }
    }
}

// ---------------------------------------------------------------- Add money

@Composable
fun AddMoneyScreen(vm: WalletViewModel, onBack: () -> Unit) {
    var amountText by remember { mutableStateOf("") }
    var cur by remember { mutableStateOf("EUR") }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        BackHeader("Add money", onBack)
        AmountRow("Amount", amountText, { amountText = it }, cur, { cur = it })
        Text("Demo: money is added instantly. In production this would be a bank transfer or card top-up.",
            color = Color.Gray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(8.dp))
        PrimaryButton("Add money", enabled = parseAmount(amountText) > 0) {
            vm.addMoney(parseAmount(amountText), cur); onBack()
        }
    }
}

// ---------------------------------------------------------------- Activity & Account

@Composable
fun ActivityScreen(vm: WalletViewModel) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        item {
            Text("Activity", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 20.dp))
        }
        items(vm.transactions, key = { it.id }) { TxRow(it) }
    }
}

@Composable
fun AccountScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(30.dp))
        Box(Modifier.size(84.dp).clip(CircleShape).background(Lime), contentAlignment = Alignment.Center) {
            Text("AI", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Forest)
        }
        Spacer(Modifier.height(12.dp))
        Text("Ali Ilyasli", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Personal account · Verified (demo)", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        listOf("Personal details", "Security & login", "Linked bank accounts", "Notifications", "Help")
            .forEach { KeyValue(it, "›") }
    }
}
