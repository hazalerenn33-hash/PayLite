package com.paylite.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paylite.app.Currencies
import com.paylite.app.Transaction
import com.paylite.app.TxType
import com.paylite.app.money
import java.time.format.DateTimeFormatter

fun parseAmount(s: String): Double = s.replace(',', '.').toDoubleOrNull() ?: 0.0

@Composable
fun BackHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(4.dp)) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Forest),
    ) { Text(text, fontWeight = FontWeight.Bold, modifier = Modifier.padding(6.dp)) }
}

@Composable
fun CurrencyPicker(selected: String, onSelect: (String) -> Unit, codes: List<String> = Currencies.all.map { it.code }) {
    var open by remember { mutableStateOf(false) }
    val c = Currencies.get(selected)
    Box {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable { open = true }
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            Text(c.flag, fontSize = 20.sp)
            Spacer(Modifier.width(6.dp))
            Text(c.code, fontWeight = FontWeight.Bold)
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            codes.forEach { code ->
                val cur = Currencies.get(code)
                DropdownMenuItem(
                    text = { Text("${cur.flag}  ${cur.code} · ${cur.name}") },
                    onClick = { onSelect(code); open = false },
                )
            }
        }
    }
}

/** Amount input with a currency picker on the right, Wise-style. */
@Composable
fun AmountRow(
    label: String,
    value: String,
    onValue: ((String) -> Unit)?,
    currency: String,
    onCurrency: (String) -> Unit,
    codes: List<String> = Currencies.all.map { it.code },
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            .padding(14.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = Color.Gray)
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onValue != null) {
                OutlinedTextField(
                    value = value,
                    onValueChange = { s -> if (s.all { it.isDigit() || it == '.' || it == ',' }) onValue(s) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("0") },
                )
            } else {
                Text(
                    value,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f).padding(vertical = 14.dp),
                )
            }
            Spacer(Modifier.width(8.dp))
            CurrencyPicker(currency, onCurrency, codes)
        }
    }
}

@Composable
fun KeyValue(k: String, v: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, color = Color.Gray)
        Text(v, fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium)
    }
}

private val dateFmt = DateTimeFormatter.ofPattern("d MMM, HH:mm")

@Composable
fun TxRow(tx: Transaction) {
    val icon = when (tx.type) {
        TxType.SENT -> Icons.Filled.ArrowUpward
        TxType.CONVERTED -> Icons.Filled.SwapHoriz
        TxType.ADDED -> Icons.Filled.Add
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, contentDescription = null, tint = Forest) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(tx.title, fontWeight = FontWeight.SemiBold)
            Text(tx.time.format(dateFmt), style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
        Column(horizontalAlignment = Alignment.End) {
            val sign = if (tx.type == TxType.ADDED) "+ " else "− "
            Text(sign + tx.fromAmount.money(tx.fromCurrency), fontWeight = FontWeight.SemiBold)
            if (tx.toCurrency != tx.fromCurrency) {
                Text(tx.toAmount.money(tx.toCurrency), style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
}
