package com.paylite.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.paylite.app.ui.AccountScreen
import com.paylite.app.ui.ActivityScreen
import com.paylite.app.ui.AddMoneyScreen
import com.paylite.app.ui.ConvertScreen
import com.paylite.app.ui.HomeScreen
import com.paylite.app.ui.Lime
import com.paylite.app.ui.PayLiteTheme
import com.paylite.app.ui.SendScreen

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("send", "Send", Icons.AutoMirrored.Filled.Send),
    Tab("activity", "Activity", Icons.AutoMirrored.Filled.ReceiptLong),
    Tab("account", "Account", Icons.Filled.Person),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PayLiteTheme {
                val vm: WalletViewModel = viewModel()
                val nav = rememberNavController()
                val entry by nav.currentBackStackEntryAsState()
                val current = entry?.destination?.route

                fun go(route: String) = nav.navigate(route) {
                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }

                Scaffold(
                    bottomBar = {
                        if (tabs.any { it.route == current }) {
                            NavigationBar {
                                tabs.forEach { t ->
                                    NavigationBarItem(
                                        selected = current == t.route,
                                        onClick = { go(t.route) },
                                        icon = { Icon(t.icon, contentDescription = t.label) },
                                        label = { Text(t.label) },
                                        colors = NavigationBarItemDefaults.colors(indicatorColor = Lime),
                                    )
                                }
                            }
                        }
                    }
                ) { padding ->
                    NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
                        composable("home") {
                            HomeScreen(
                                vm,
                                onSend = { go("send") },
                                onConvert = { nav.navigate("convert") },
                                onAdd = { nav.navigate("add") },
                                onSeeAll = { go("activity") },
                            )
                        }
                        composable("send") { SendScreen(vm, onDone = { go("home") }) }
                        composable("activity") { ActivityScreen(vm) }
                        composable("account") { AccountScreen() }
                        composable("convert") { ConvertScreen(vm, onBack = { nav.popBackStack() }) }
                        composable("add") { AddMoneyScreen(vm, onBack = { nav.popBackStack() }) }
                    }
                }
            }
        }
    }
}
