package com.paylite.app

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.ViewModel
import java.time.LocalDateTime
import java.util.Locale
import java.util.UUID

data class Currency(val code: String, val name: String, val flag: String, val symbol: String)

data class Recipient(
    val id: String,
    val name: String,
    val currency: String,
    val account: String,
)

enum class TxType { SENT, CONVERTED, ADDED }

data class Transaction(
    val id: String = UUID.randomUUID().toString(),
    val type: TxType,
    val title: String,
    val fromAmount: Double,
    val fromCurrency: String,
    val toAmount: Double,
    val toCurrency: String,
    val fee: Double,
    val time: LocalDateTime = LocalDateTime.now(),
)

data class Quote(
    val sendAmount: Double,
    val fee: Double,
    val amountConverted: Double,
    val rate: Double,
    val receiveAmount: Double,
)

object Currencies {
    val all = listOf(
        Currency("EUR", "Euro", "🇪🇺", "€"),
        Currency("PLN", "Polish złoty", "🇵🇱", "zł"),
        Currency("USD", "US dollar", "🇺🇸", "$"),
        Currency("GBP", "British pound", "🇬🇧", "£"),
        Currency("TRY", "Turkish lira", "🇹🇷", "₺"),
        Currency("AZN", "Azerbaijani manat", "🇦🇿", "₼"),
    )

    fun get(code: String) = all.first { it.code == code }

    // Demo rates: 1 EUR = x. Replace with a live FX API in production.
    val ratePerEur = mapOf(
        "EUR" to 1.0,
        "PLN" to 4.27,
        "USD" to 1.08,
        "GBP" to 0.84,
        "TRY" to 37.6,
        "AZN" to 1.84,
    )
}

fun Double.money(code: String): String =
    String.format(Locale.US, "%,.2f %s", this, code)

class WalletViewModel : ViewModel() {

    val balances = mutableStateMapOf(
        "EUR" to 1250.00,
        "PLN" to 3400.00,
        "USD" to 410.50,
        "TRY" to 0.0,
    )

    val recipients = mutableStateListOf(
        Recipient("1", "Kaja Sawicka", "PLN", "PL61 1090 •••• 4521"),
        Recipient("2", "Mehmet Yılmaz", "TRY", "TR33 0006 •••• 1290"),
        Recipient("3", "John Smith", "GBP", "GB29 NWBK •••• 2681"),
    )

    val transactions = mutableStateListOf(
        Transaction(
            type = TxType.SENT, title = "Kaja Sawicka",
            fromAmount = 200.0, fromCurrency = "EUR",
            toAmount = 852.4, toCurrency = "PLN", fee = 1.5,
            time = LocalDateTime.now().minusDays(2),
        ),
        Transaction(
            type = TxType.ADDED, title = "Added from bank",
            fromAmount = 1000.0, fromCurrency = "EUR",
            toAmount = 1000.0, toCurrency = "EUR", fee = 0.0,
            time = LocalDateTime.now().minusDays(5),
        ),
    )

    fun rate(from: String, to: String): Double =
        Currencies.ratePerEur.getValue(to) / Currencies.ratePerEur.getValue(from)

    /** Simple transparent fee: 0.45% + fixed 0.50 EUR equivalent. */
    fun quote(amount: Double, from: String, to: String): Quote {
        if (amount <= 0) return Quote(0.0, 0.0, 0.0, rate(from, to), 0.0)
        val fixed = 0.50 * rate("EUR", from)
        val fee = if (from == to) 0.0 else amount * 0.0045 + fixed
        val converted = (amount - fee).coerceAtLeast(0.0)
        val r = rate(from, to)
        return Quote(amount, fee, converted, r, converted * r)
    }

    fun totalInEur(): Double =
        balances.entries.sumOf { (code, v) -> v * rate(code, "EUR") }

    fun send(amount: Double, from: String, recipient: Recipient): Result<Quote> {
        val q = quote(amount, from, recipient.currency)
        val bal = balances[from] ?: 0.0
        if (amount <= 0) return Result.failure(IllegalArgumentException("Enter an amount"))
        if (amount > bal) return Result.failure(IllegalStateException("Insufficient balance"))
        balances[from] = bal - amount
        transactions.add(
            0,
            Transaction(
                type = TxType.SENT, title = recipient.name,
                fromAmount = amount, fromCurrency = from,
                toAmount = q.receiveAmount, toCurrency = recipient.currency, fee = q.fee,
            )
        )
        return Result.success(q)
    }

    fun convert(amount: Double, from: String, to: String): Result<Quote> {
        val bal = balances[from] ?: 0.0
        if (amount <= 0) return Result.failure(IllegalArgumentException("Enter an amount"))
        if (amount > bal) return Result.failure(IllegalStateException("Insufficient balance"))
        if (from == to) return Result.failure(IllegalArgumentException("Pick two different currencies"))
        val q = quote(amount, from, to)
        balances[from] = bal - amount
        balances[to] = (balances[to] ?: 0.0) + q.receiveAmount
        transactions.add(
            0,
            Transaction(
                type = TxType.CONVERTED, title = "Converted $from → $to",
                fromAmount = amount, fromCurrency = from,
                toAmount = q.receiveAmount, toCurrency = to, fee = q.fee,
            )
        )
        return Result.success(q)
    }

    fun addMoney(amount: Double, currency: String) {
        if (amount <= 0) return
        balances[currency] = (balances[currency] ?: 0.0) + amount
        transactions.add(
            0,
            Transaction(
                type = TxType.ADDED, title = "Added from bank",
                fromAmount = amount, fromCurrency = currency,
                toAmount = amount, toCurrency = currency, fee = 0.0,
            )
        )
    }

    fun addRecipient(name: String, currency: String, account: String) {
        recipients.add(Recipient(UUID.randomUUID().toString(), name, currency, account))
    }
}
