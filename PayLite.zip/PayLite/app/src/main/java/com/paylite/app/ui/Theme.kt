package com.paylite.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Lime = Color(0xFF9FE870)
val Forest = Color(0xFF163300)
val Mist = Color(0xFFF2F5EE)

private val Colors = lightColorScheme(
    primary = Forest,
    onPrimary = Color.White,
    secondary = Lime,
    onSecondary = Forest,
    background = Color.White,
    surface = Color.White,
    surfaceVariant = Mist,
    onSurface = Color(0xFF0E0F0C),
    error = Color(0xFFC9302C),
)

@Composable
fun PayLiteTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
